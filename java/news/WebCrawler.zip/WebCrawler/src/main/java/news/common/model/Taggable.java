package news.common.model;

public interface Taggable {
    void addTag(String tag);
}
