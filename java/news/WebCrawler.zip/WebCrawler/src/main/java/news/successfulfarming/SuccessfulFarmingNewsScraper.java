package news.successfulfarming;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import news.common.repository.NewsRepository;
import news.common.scraper.FirstGetThenPostHTMLWebpageNewsScraper;
import org.apache.commons.lang.StringUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import java.util.concurrent.TimeUnit;

public class SuccessfulFarmingNewsScraper extends FirstGetThenPostHTMLWebpageNewsScraper<SuccessfulFarmingNews, SuccessfulFarmingNewsBuilder> {
    private final String category;
    private final int categoryNumber;

    public SuccessfulFarmingNewsScraper(NewsRepository<?, ?> repository, int interval, TimeUnit timeUnit, String urlToGet, String urlToPost, Category category) throws IllegalArgumentException {
        super(repository, interval, timeUnit, urlToGet, urlToPost);
        this.category = category.name().toLowerCase();
        this.categoryNumber = category.getCategoryNumber();
    }

    @Override
    protected String getHeadlineSelector() {
        return ".recent-content-title-teaser";
    }

    @Override
    protected SuccessfulFarmingNewsBuilder createNewsBuilder() throws Exception {
        return new SuccessfulFarmingNewsBuilder(category);
    }

    @Override
    public Element convertResponse(Connection.Response response, int page) throws NoHeadlineFoundException {
        JsonArray jsonArray = new Gson().fromJson(response.body(), JsonArray.class);
        String data = jsonArray.get(1).getAsJsonObject().getAsJsonPrimitive("data").getAsString();
        if (StringUtils.isEmpty(data)) {
            throw new NoHeadlineFoundException(page);
        }
        return Jsoup.parse(data);
    }

    @Override
    public String generateRequestBody(int page) {
        return "view_name=category_content&view_display_id=category_recent_content_offset_three&view_args=" + categoryNumber + "&page=" + page;
    }

    public enum Category {
        BUSINESS(70),
        NEWSWIRE(77),
        COMMODITY_PRICE(78),
        CROP_MARKET_ANALYSIS(79)
        ;
        private final int categoryNumber;

        Category(int categoryNumber) {
            this.categoryNumber = categoryNumber;
        }

        public int getCategoryNumber() {
            return categoryNumber;
        }

        public String getName() {
            return this.name().toLowerCase();
        }
    }

    public static void main(String[] args) {
        Category category = Category.BUSINESS;
        System.out.println(category.name());
        MongoDBSuccessfulFarmingNewsRepository mongoDBSuccessfulFarmingNewsRepository = new MongoDBSuccessfulFarmingNewsRepository(category);
        SuccessfulFarmingNewsScraper successfulFarmingNewsScraper = new SuccessfulFarmingNewsScraper(mongoDBSuccessfulFarmingNewsRepository, 500, TimeUnit.MILLISECONDS, "https://www.agriculture.com/news/business", "https://www.agriculture.com/views/ajax", category);
        Thread thread = new Thread(successfulFarmingNewsScraper);
        thread.start();
    }
}
