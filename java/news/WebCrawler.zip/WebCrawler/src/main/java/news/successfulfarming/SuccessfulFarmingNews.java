package news.successfulfarming;

import com.google.gson.JsonObject;
import news.common.model.Categorical;
import news.common.model.WebpageNews;
import news.common.repository.NewsRepository;

import java.util.Collections;
import java.util.Set;

public class SuccessfulFarmingNews extends WebpageNews implements Categorical {
    public static final String SOURCE_NAME = "SuccessfulFarming";
    @NewsRepository.DBField(name = "categories")
    private final Set<String> categories;

    public SuccessfulFarmingNews(String id, String url, String headline, String subheading, String category) {
        super(id, url);
        setHeadline(headline);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("subheading", subheading);
        categories = Collections.singleton(category);
    }

    @Override
    public Set<String> getCategories() {
        return categories;
    }
}
