package news.common.repository;

import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import news.common.model.Categorical;
import news.common.model.News;
import org.bson.Document;
import org.bson.conversions.Bson;

public class UpdatableMongoDBNewsRepository extends MongoDBNewsRepository {
    private final String category;

    public UpdatableMongoDBNewsRepository(String source, String category) {
        super(source);
        this.category = category;
    }

    @Override
    public void save(News news) {
        try {
            if (exists(news)) {
                newsCollection.findOneAndUpdate(getExactFilter(news), Updates.addToSet("categories", ((Categorical) news).getCategory()));
            } else {
                newsCollection.insertOne(toDBObject(news));
            }
        } catch (Exception e) {
            error(e, this.getClass(), news.toJSON().toString());
        }
    }

    protected Bson getExactFilter(News news) {
        return Filters.eq("_id", generateID(news));
    }

    @Override
    protected Bson getSearchCriteria() {
        return Filters.and(
                super.getSearchCriteria(),
                Filters.in("categories", category)
        );
    }

    @Override
    protected Document createLog(Throwable throwable, Class<?> origin, String additionalMessage, LogSeverity severity) {
        Document log = super.createLog(throwable, origin, additionalMessage, severity);
        log.append("category", category);
        return log;
    }
}
