package news.common.model;

import common.URLAccessible;
import news.common.repository.NewsRepository;

public class
WebpageNews extends News implements URLAccessible {
    @NewsRepository.DBField(name = "url")
    protected final String url;

    public WebpageNews(String id, String url) {
        super(id);
        this.url = url;
    }

    @Override
    public String getURL() {
        return url;
    }
}
