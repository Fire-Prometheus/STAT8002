package common;

public interface URLAccessible {
    String getURL();
}
